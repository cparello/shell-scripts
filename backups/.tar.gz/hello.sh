#!/bin/bash
MY_SHELL="bash"
echo "I am $MY_SHELL"

if [ "$MY_SHELL" = "bash" ]
then
	echo " YES "
else
	echo " NOT "
fi

