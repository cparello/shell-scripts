#!/bin/bash

for COLOR in red green blue
do
  echo "COLOR: $COLOR"
done
